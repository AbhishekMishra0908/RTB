package job;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name="jobservice")
public class JobServiceApplication 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
private int id;
	@Column(name="job_id")
private int jobid;
@Column(name="application_id")
private int applicationid;
@Column(name="created1",nullable = false, updatable = false)
@CreationTimestamp
 
    private LocalDateTime createDateTime1;
 
public LocalDateTime getCreateDateTime1() {
	return createDateTime1;
}
public void setCreateDateTime(LocalDateTime createDateTime1) {
	this.createDateTime1 = createDateTime1;
}

public int getId()
{
	return id;
}
public void setId(int id) 
{
	this.id = id;
}
public int getJobid()
{
	return jobid;
}
public void setJobid(int jobid) 
{
	this.jobid = jobid;
}
public int getApplicationid()
{
	return applicationid;
}
public void setApplicationid(int applicationid) 
{
	this.applicationid = applicationid;
}

}
