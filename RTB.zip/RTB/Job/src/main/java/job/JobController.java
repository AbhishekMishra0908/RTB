package job;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class JobController 
{
	@Autowired
	private JobServiceImplementation jobservimple;
	@Autowired
	private JobServicerepo jobservrepo;

	
	@RequestMapping(method=RequestMethod.GET,value="/job/list")
	public List<Job> getAlljobs()
	{
		return jobservimple.getAlljobs();
		
	}
	@RequestMapping(value="/getjob/{jobid}",method=RequestMethod.GET)
	public Job getjob(@PathVariable("jobid") Integer jobid, @RequestBody Job job) 
	{
		return jobservimple.getjob(jobid);
		
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/createjob")
	public Job createJob(@RequestBody Job job)
	{
		return jobservimple.createJob(job);

}
	
	
   
	@RequestMapping(value="/getall")
public List<JobServiceApplication>	getAllappliedjobs(){
	return jobservimple.getAllappliedjobs();
}

	@RequestMapping(value="/apply",method=RequestMethod.POST)
	public void applyjob(@RequestBody JobServiceApplication jobservapp)
	{
		jobservimple.associateApplicationWithjob(jobservapp);
	}
	/*@PutMapping("/updatejob/{id}")
	public Job updatejob(@PathVariable(value = "id") Integer id,
	                                        @RequestBody Job job)
	                                        
	{

	    Job job1= jobservimple.getjob(id);
	            

	    job1.setId(job.getId());
	    job1.setDescription(job.getDescription());
	    job1.setSalary(job.getSalary());
	    job1.setExperience(job.getExperience());
	    job1.setLocation(job.getLocation());

	    Job updatedjob = jobservrepo.save(job1);
	    return updatedjob;
	}*/

@RequestMapping(value = "/job/update/{id}", method = RequestMethod.PUT, headers = "Accept=application/json")
public Job updatejob(@RequestBody Job job, @PathVariable("id") int id)
{
	return jobservimple.updatejob(job);
	}
	 @RequestMapping(value= "/job/delete/{id}", method= RequestMethod.DELETE)

	    public void deletejob(@PathVariable("id") int id, Job job2)
	 {
	        Job job3 = jobservrepo.findById(id)
	        		
	          .orElseThrow(() -> new IllegalArgumentException("Invalid event Id:" + id));
	       jobservrepo.delete(job3);
	   
	    }
	
	
	
	
	
	
	
	
}