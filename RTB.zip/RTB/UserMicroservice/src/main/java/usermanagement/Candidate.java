package usermanagement;




import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

import javax.persistence.Table;



//import javax.persistence.Table;


@Entity(name="Candidate")
@Table(name="useraccount")
@DiscriminatorValue("Candidate")
public class Candidate extends User
{
@Column(name="experience")
	private int experience;

@Column(name="primaryskills")
	private String primaryskills;
@Column(name="qualification")
private String qualification;



	public Candidate()
	{
		
	}
	
	public Candidate(int experience, String primaryskills,String qualification) 
	{
	
		this.experience = experience;
		this.qualification = qualification;
		this.primaryskills = primaryskills;
	}
	public int getExperience()
	{
		return experience;
	}
	public void setExperience(int experience)
	{
		this.experience = experience;
	}
	public String getQualification()
	{
		return qualification;
	}
	public void setQualification(String qualification)
	{
		this.qualification = qualification;
	}
	public String getPrimaryskills()
	{
		return primaryskills;
	}
	public void setPrimaryskills(String primaryskills) 
	{
		this.primaryskills = primaryskills;
	}
}