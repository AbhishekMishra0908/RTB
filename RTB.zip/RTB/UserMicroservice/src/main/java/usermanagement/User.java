package usermanagement;

import java.time.LocalDateTime;


import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.DiscriminatorOptions;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name="useraccount")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)//The single table strategy maps all entities of the inheritance structure to the same database table.
@DiscriminatorColumn(name = "type", discriminatorType = DiscriminatorType.STRING,columnDefinition="VARCHAR(10)")
@DiscriminatorOptions(force = true) 
		
		
		
public class User {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
private int id;
	
	@Column(name="name")
	@Size(min=5,max=20)
private String name;
	@Column(name="email")
	@Size(min=7,max=30)
private String email;
	@Column(name="password")
	@Size(min=8)
private String password;
	@Column(name="address")
private String address;
	
	@Column(name="mobile")
	@Size(min=10,max=10)
private String mobile;
	 @Column(name="type", insertable = false, updatable = false)         
	    private String type;    

	@Column(name="createdon",nullable = false, updatable = false)
	@CreationTimestamp
	 
	    private LocalDateTime createonDateTime;
	 @Column(name="updatedon")
	    @UpdateTimestamp
	   
	    private LocalDateTime updateonDateTime;
	
public User()
{

}

public User( String name, String email, String password, String address, String mobile) 
{
	super();

	this.name = name;
	this.email = email;
	this.password = password;
	this.address = address;
	this.mobile = mobile;

}
public int getId()
{
	return id;
}
public void setId(int id) 
{
	this.id = id;
}
public String getName()
{
	return name;
}
public void setName(String name) 
{
	this.name = name;
}
public String getEmail() 
{
	return email;
}
public void setEmail(String email) 
{
	this.email = email;
}
public String getPassword()
{
	return password;
}
public void setPassword(String password) 
{
	this.password = password;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) 
{
	this.address = address;
}
public String getMobile() 
{
	return mobile;
}
public void setMobile(String mobile)
{
	this.mobile = mobile;
}

public String getType() {
	return type;
}

public void setType(String type) {
	this.type = type;
}

public LocalDateTime getCreateonDateTime() {
	return createonDateTime;
}

public void setCreateonDateTime(LocalDateTime createonDateTime) {
	this.createonDateTime = createonDateTime;
}

public LocalDateTime getUpdateonDateTime() {
	return updateonDateTime;
}

public void setUpdateonDateTime(LocalDateTime updateonDateTime) {
	this.updateonDateTime = updateonDateTime;
}




   
    }



